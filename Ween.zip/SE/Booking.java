package SE;

public class Booking {
    Accommodation accommodation;
    String review; 
    int rating;    

    public Booking(Accommodation accommodation) {
        this.accommodation = accommodation;
    }

    public void addReview(String review, int rating) {
        this.review = review;
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public int getRating() {
        return rating;
    }
}
