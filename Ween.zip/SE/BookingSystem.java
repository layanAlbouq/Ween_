package SE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookingSystem {
    private Map<String, User> users = new HashMap<>();
    private List<Accommodation> accommodations = new ArrayList<>();

    public BookingSystem() {
        // Sample users
        users.put("user1", new User("user1", "password1"));
        users.put("user2", new User("user2", "password2"));

        // Sample accommodations
        accommodations.add(new Accommodation("Ritz-Carlton", "Riyadh", 1200)); 
        accommodations.add(new Accommodation("InterContinental", "Jeddah", 800)); 
        accommodations.add(new Accommodation("Dar Al Tawhid Intercontinental", "Mecca", 1000)); 
    }

    public boolean login(String username, String password) {
        User user = users.get(username);
        return user != null && user.getPassword().equals(password);
    }

    public User getUser(String username) {
        return users.get(username);
    }

    public List<Accommodation> searchAccommodations(String location) {
        List<Accommodation> results = new ArrayList<>();
        for (Accommodation acc : accommodations) {
            if (acc.location.equalsIgnoreCase(location)) {
                results.add(acc);
            }
        }
        return results;
    }

    public void bookAccommodation(User user, Accommodation accommodation) {
        for (Booking booking : user.getBookingHistory()) {
            if (booking.accommodation.equals(accommodation)) {
                System.out.println("You have already booked this accommodation");
                return;
            }
        }

        Booking booking = new Booking(accommodation);
        user.addBooking(booking);
        System.out.println("Successfully booked: " + accommodation.name);
    }

    public String getWeatherUpdate(String location) {
        return "Current weather in " + location + ": Sunny, 75°F";
    }

    public void leaveReview(User user, Accommodation accommodation, String review, int rating) {
        for (Booking booking : user.getBookingHistory()) {
            if (booking.accommodation.equals(accommodation)) {
                booking.addReview(review, rating);
                accommodation.addReview(booking);
                System.out.println("Review added: " + review + " with rating: " + rating);
                return;
            }
        }
        System.out.println("You need to book this accommodation to leave a review");
    }
}

