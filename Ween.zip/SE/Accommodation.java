package SE;

import java.util.ArrayList;
import java.util.List;

public class Accommodation {
    String name;
    String location;
    double price;
    private List<Booking> bookings = new ArrayList<>(); 

    public Accommodation(String name, String location, double price) {
        this.name = name;
        this.location = location;
        this.price = price;
    }

    public void addReview(Booking booking) {
        bookings.add(booking); 
    }

    public List<Booking> getBookings() {
        return bookings; 
    }
    @Override
    public String toString() {
        return name + " | Location: " + location + " | Price: $" + String.format("%.2f", price);
    }
}
