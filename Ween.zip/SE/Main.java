package SE;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class Main {
    private BookingSystem system;
    private User currentUser;

    public Main() {
        system = new BookingSystem();
        showLoginScreen();
    }

    private void showLoginScreen() {
        JFrame frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel usernameLabel = new JLabel("Username:");
        JTextField usernameField = new JTextField(20);
        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            if (system.login(username, password)) {
                currentUser = system.getUser(username);
                frame.dispose();
                showSearchScreen();
            } else {
                JOptionPane.showMessageDialog(frame, "Login failed. Try again.");
            }
        });

        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(usernameLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        frame.add(usernameField, gbc);
        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(passwordLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        frame.add(passwordField, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        frame.add(loginButton, gbc);

        frame.setVisible(true);
    }

    private void showSearchScreen() {
        JFrame frame = new JFrame("Search Accommodations");
        frame.setSize(450, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel locationLabel = new JLabel("Enter Location:");
        JTextField locationField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        JTextArea resultsArea = new JTextArea(10, 30);
        resultsArea.setEditable(false);
        resultsArea.setFont(new Font("Arial", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(resultsArea);
        JLabel promptLabel = new JLabel("Enter the number of the accommodation to book:");
        JTextField bookingNumberField = new JTextField(5);
        JButton bookButton = new JButton("Book Selected");

        searchButton.addActionListener(e -> {
            String location = locationField.getText();
            List<Accommodation> results = system.searchAccommodations(location);
            resultsArea.setText("");
            if (results.isEmpty()) {
                resultsArea.setText("No accommodations found in " + location);
            } else {
                for (int i = 0; i < results.size(); i++) {
                    resultsArea.append((i + 1) + ". " + results.get(i) + "\n");
                }
            }
        });

        bookButton.addActionListener(e -> {
            String bookingNumber = bookingNumberField.getText();
            try {
                int selectedIndex = Integer.parseInt(bookingNumber) - 1;
                if (selectedIndex >= 0) {
                    Accommodation selectedAccommodation = system.searchAccommodations(locationField.getText()).get(selectedIndex);
                    system.bookAccommodation(currentUser, selectedAccommodation);
                    JOptionPane.showMessageDialog(frame, "Successfully booked: " + selectedAccommodation.name);
                    frame.dispose();  // Close the current search screen
                    showReviewScreen(selectedAccommodation); // Show review screen
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
                }
            } catch (NumberFormatException | IndexOutOfBoundsException ex) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid accommodation number.");
            }
        });

        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(locationLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        frame.add(locationField, gbc);
        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(searchButton, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        frame.add(scrollPane, gbc);
        gbc.gridx = 0; gbc.gridy = 3;
        frame.add(promptLabel, gbc);
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 1;
        frame.add(bookingNumberField, gbc);
        gbc.gridx = 1; gbc.gridy = 4;
        frame.add(bookButton, gbc);

        frame.setVisible(true);
    }

    private void showReviewScreen(Accommodation accommodation) {
        JFrame frame = new JFrame("Leave a Review");
        frame.setSize(450, 400); // Increased size for more space
        frame.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel reviewLabel = new JLabel("Review:");
        JTextArea reviewField = new JTextArea(8, 30); // Increased rows for more space
        reviewField.setFont(new Font("Arial", Font.PLAIN, 16)); // Increased font size
        JScrollPane reviewScrollPane = new JScrollPane(reviewField); // Wrap in scroll pane
        reviewScrollPane.setPreferredSize(new Dimension(400, 200)); // Set preferred size

        JSpinner ratingSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 5, 1));
        JButton submitButton = new JButton("Submit Review");

        submitButton.addActionListener(e -> {
            String review = reviewField.getText();
            int rating = (int) ratingSpinner.getValue();
            system.leaveReview(currentUser, accommodation, review, rating);
            
            // Display confirmation message
            JOptionPane.showMessageDialog(frame, "Review added: " + review + " with rating: " + rating);
            
            frame.dispose();
            showWeatherScreen(accommodation.location);
        });

        gbc.gridx = 0; gbc.gridy = 0;
        frame.add(reviewLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        frame.add(reviewScrollPane, gbc); // Add scroll pane instead of text area
        gbc.gridx = 0; gbc.gridy = 1;
        frame.add(new JLabel("Rating (1-5):"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        frame.add(ratingSpinner, gbc);
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        frame.add(submitButton, gbc);

        frame.setVisible(true);
    }

    private void showWeatherScreen(String location) {
        JFrame frame = new JFrame("Weather Update");
        frame.setSize(300, 100);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JLabel weatherLabel = new JLabel(system.getWeatherUpdate(location));
        weatherLabel.setHorizontalAlignment(SwingConstants.CENTER);
        frame.add(weatherLabel);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Main::new);
    }
}
